A Pen created at CodePen.io. You can find this one at https://codepen.io/kathykato/pen/rZRaNe.

 Pure CSS (SCSS) arrow button hover effect.